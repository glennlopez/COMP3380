# -*- coding: utf-8 -*-
"""
Created on Sun Nov 14 19:09:13 2021

@author: Adam Pazdor
"""

from mydatabase import MyDatabase

def main():
    db = MyDatabase(False)
    runConsole(db)
    #db.deleteCouncilor("Brian Bowman")
    #db.allCouncilors()
    print("Exiting")
    db.close()
    
def getPieces(data):
    one = data[0].lower()
    two = None
    if len(data) > 1:
        two = " ".join(data[1:])
    return one, two
    
def runConsole(db):
    user = " "
    
    while len(user) and user!= "q":
        user = input("db > ")
        inputs = user.strip().split()
        main, second = getPieces(inputs)
        
        if main == "h":
            printHelp()
        elif main == "w":
            db.allWards()
        elif main == "c":
            db.allCouncilors()
        elif main == "e":
            db.allExpenses()
        elif main == "ct":
            if second:
                db.singleCouncilor(second)
            else:
                print("A second parameter is required")
        elif main == "wt":
            if second:
                db.singleWard(second)
            else:
                print("A second parameter is required")
        elif main == "dc":
            if second:
                db.deleteCouncilor(second)
            else:
                print("A second parameter is required")
        elif main == "de":
            if second:
                db.deleteExpense(second)
            else:
                print("A second parameter is required")
        elif main == "m":
            db.highestExpense()
        elif main != "q":
            print("Enter h to view help, or find help somewhere else.")
            
        
    
    
    
    
def printHelp():
    print("Winnipeg Council Member Expenses console")
    print("Commands:")
    print("h - Get help")
    print("w - Print all wards")
    print("c - Print all coucillors")
    print("ct name - Print total expenses for councilors 'name'")
    print("wt name - Print total expenses for ward 'name'")
    print("dc name - Delete councilors named 'name'")
    print("de id - delete expense 'id'")
    print("m - Show the highest single-time expense for each councilors")
    print("q - Exit the program")
    print("---- end help ----- ")

if __name__ == "__main__":
    main()