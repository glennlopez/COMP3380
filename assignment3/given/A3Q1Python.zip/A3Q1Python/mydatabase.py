# -*- coding: utf-8 -*-
"""
Created on Sun Nov 14 18:56:24 2021

@author: Adam Pazdor
"""
import sqlite3

FILENAME = "Council_Member_Expenses.csv"

class MyDatabase:
    def __init__(self,create=True):
        self.cur = None
        try:
            self.con = sqlite3.connect("council.db")
            self.cur = self.con.cursor()
            if create:
                self.createTables()
                self.readInData()
                self.con.commit()
        except Exception as ex:
            print(ex)
            
    '''CREATION FUNCTIONS'''
    def close(self):
        self.con.close()
            
    def createTables(self):
        try:
            self.cur.execute('''create table wards (  wardID integer, 
                    name VARCHAR(60), primary key(wardID))''')
            self.cur.execute('''create table councilors ( cID integer primary key, 
                             wardID integer, name VARCHAR(60), foreign key (wardID) references wards)''')
            self.cur.execute('''create table expenses ( eID integer primary key, 
                             cID integer, description VARCHAR(200),  
                             account VARCHAR(60),  amount DECIMAL, 
                             foreign key (cID) references councilors on delete cascade)''')
            self.con.commit()
        except Exception as ex:
            print(ex)
            
    def execute(self,query,*args):
        queries = query.split(";")
        results = []
        for idx, query in enumerate(queries):
            #print(query)
            query = query.strip()
            if idx == 0 and args and (isinstance(args[0],int) or len(args[0])):
                self.cur.execute(query,args)
            else:
                self.cur.execute(query)
            if "SELECT" in query:
                rr = self.cur.fetchall()
                if rr:
                    results.extend(rr)
        if results:
            return results
        
    def getOrMakeWard(self, ss, name):
        nn = -1
        try:
            wardID = int(ss)
            matches = self.execute("SELECT * FROM Wards WHERE wardID = ?;",wardID)
            if matches: #There is a match
                nn = matches[0][0]
            else:
                self.execute("INSERT INTO WARDS (wardID, name) VALUES (?, ?);",
                                 wardID, name)
                nn = wardID
        except Exception as e:
            print(e)
            
        return nn
    
    def getOrMakeCouncilor(self, name, ward):
        num = -1;
        try:
            matches = self.execute("SELECT cID FROM Councilors WHERE name = ?;",name)
            if matches: #There is a match
                num = matches[0][0]
            else:
                self.execute("INSERT INTO COUNCILORS (name, wardID) VALUES (?, ?);",
                                 name, ward)
                matches = self.execute("SELECT cID FROM Councilors WHERE name = ?;",name)
                num = matches[0][0]
        except Exception as e:
            print(e)
        return num
        
    
    def readInData(self):
        try:
            with open(FILENAME,encoding="utf-8") as file:
                lines = file.readlines()
            #header = lines[0]
            insertLine = "insert into expenses  (cID, description, account, amount) values (?, ?, ?, ?);"
            
            for line in lines[1:]:
                clean = line.strip().split(",")
                length = len(clean)
                
                ward = self.getOrMakeWard(clean[0],clean[1])
                councilor = self.getOrMakeCouncilor(clean[2],ward)
                self.execute(insertLine,councilor,clean[length-3],clean[length-2],
                                 float(clean[length-1]))
        except Exception as e:
            print(e)
            
    '''DELETION'''
    def deleteExpense(self, eid):
        try:
            sql = "delete from expenses where eID = {};".format(eid)
            self.execute(sql)
            #self.con.commit()
        except Exception as e:
            print(e)
        
    def deleteCouncilor(self, name):
        try:
            sql = "delete from councilors where name = '" + name + "';"
            self.execute(sql)
            #self.con.commit()
        except Exception as e:
            print(e)
    
    '''SELECTION'''
    def makeSelection(self, fmt, pos, query, *args):
        try:
            results = self.execute(query, *args)
            for row in results:
                data = []
                for pp in pos:
                    data.append(row[pp])
                print(fmt.format(*data))
            
        except Exception as e:
            print(e)
    
    def allCouncilors(self):
        sql = "SELECT * FROM Councilors"
        self.makeSelection("{:3d}: {}",[0,2],sql)
            
    def allExpenses(self):
        sql = "SELECT eID, C.name, W.name, description, amount FROM Councilors C JOIN Expenses E ON C.cID = E.cID JOIN Wards W ON W.wardID = C.wardID"
        self.makeSelection("{:3d} - {}, {}, {}: ${}", [0,1,2,3,4], sql)
        
    def allWards(self):
        sql = "SELECT * FROM Wards"
        self.makeSelection("{}: {}", [0,1], sql)
    
    def singleCouncilor(self,name):
        sql = "SELECT name, sum(amount) FROM Councilors C JOIN Expenses E ON C.cID = E.cID WHERE name = '"+ name +"' GROUP BY name" #INSECURE!!
        self.makeSelection("{} : {:.1f}", [0,1], sql)
    
    def singleWard(self, name):
        sql = "SELECT W.name, sum(amount) from Wards W JOIN Councilors C ON W.wardID = C.wardID JOIN Expenses E on C.cID = E.cID where W.name = ? GROUP BY W.name;"
        self.makeSelection("{} : {:.1f}", [0,1], sql, name)
        
    def highestExpense(self):
        sql = '''SELECT C.name, max(amount) 
                    FROM Councilors C JOIN Expenses E ON C.cID = e.cID 
                    GROUP BY C.name'''
        self.makeSelection("{}: {}", [0,1], sql)